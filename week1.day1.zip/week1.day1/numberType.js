let digit = 0
if(digit>0)
{
    console.log("It is Positive Number")
}
else if(digit<0)
{
    console.log("It is Negative Number")
}
else
{
    console.log("It is Neutral Number")
}