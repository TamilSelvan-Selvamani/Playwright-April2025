//console.log(browserVersion)
const browserVersion = "Chrome"
console.log(browserVersion)

console.log(versionControl)
var versionControl = 2.0
console.log(versionControl)
versionControl = 3.0
console.log(versionControl)

//console.log(isPresent)
let isPresent = true
console.log(isPresent)
isPresent = false
console.log(isPresent)