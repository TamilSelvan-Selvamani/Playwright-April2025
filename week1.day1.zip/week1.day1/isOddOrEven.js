let digit = 6
cal = digit%2
if(cal==0)
{
    console.log("It is even number")
}
else
{
    console.log("It is odd number")
}