let firstName = "tamil"
let companyName = 'string'
let mobileNumber = 9600722980n
let isAutomation = true
let hasPlaywright = "yes"
let number = 23
console.log(typeof(firstName))
console.log(typeof(companyName))
console.log(typeof(mobileNumber))
console.log(typeof(isAutomation))
console.log(typeof(hasPlaywright))
console.log(typeof(number))