var tname    = 'testleaf'              // String
var age                = 23  // Number
var isStudent        = true   // Boolean
var grade           = null   // Null
var address           // Undefined
var bigNum    = 1212123232324423n       // BigInt
console.log(tname, age, isStudent, grade, address, bigNum)
var stringToNumber = "23"
console.log(typeof(+stringToNumber)+" =This is converted to number")
var numberString
var numberToString =48
console.log(typeof(numberString+"")+" :This is converted to string")


console.log(typeof(tname, age, isStudent, grade, address, bigNum))

//Dilip I have just created simple execution based on seession for hoisting concep. correct me if im wrong.

// Var Hoisting
console.log(v)
var v ="van"
//o/p will be undefined, as dilip said Var accept undefined

//let Hoisting
console.log(l)
let l ="lion"
//o/p Will get an error as 'Cannot access 'l' before initialization' because let will has TDZ concept

// const Hoisting
console.log(h)
const h ='home'
//o/p Will get an error as 'Cannot access 'h' before initialization' because const will has TDZ concept




